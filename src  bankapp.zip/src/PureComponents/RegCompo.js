import React, { Component } from 'react'

export default class RegCompo extends Component {
  render() {
    console.log("****Rendered Regular Component*****")
    return (
      <div>RegCompo {this.props.name}</div>
    )
  }
}
