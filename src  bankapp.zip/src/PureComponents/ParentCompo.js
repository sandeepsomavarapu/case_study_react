import React, { Component } from 'react'
import RegCompo from './RegCompo'
import PureCompo from './PureCompo'
class ParentCompo extends Component {
 constructor(props) {
   super(props)
 
   this.state = {
      name:'CTS'
   }
 }
 componentDidMount()
 {
    setInterval(()=>{
        this.setState({
            name:'CTS'
        })
    },2000)
 }
 //shouldcomponentUpdate -->True
  render() {
    console.log("****Rendered Parent Component*****")
    return (
      <div>
            <h1>Parent Component</h1>
        <RegCompo name={this.state.name}/>
        <PureCompo name={this.state.name}/>
      </div>
    )
  }
}

export default ParentCompo