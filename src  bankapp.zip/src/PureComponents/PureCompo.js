import React, { PureComponent } from 'react'

 class PureCompo extends PureComponent {
  render() {
    console.log("****Rendered Pure Component*****")
    return (
      <React.Fragment>
        <h1>PureCompo  {this.props.name}</h1>
       </React.Fragment>
    )
  }
}

export default PureCompo