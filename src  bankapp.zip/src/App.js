import React, { Component } from 'react';
import './App.css'
import { PropTypesEx } from './PropTypes/PropTypesEx';
import { PropTypeEx1 } from './PropTypes/PropTypeEx1';
import { Fetch } from './Axios/Fetch';
// import ClickCounter from './HigherOrderComponent/ClickCounter';
// import HoverCounter from './HigherOrderComponent/HoverCounter';
// import HoverCounter1 from './HigherOrderComponent/HoverCounter';
// import ClickCounter1 from './HigherOrderComponent/ClickCounter1';
// import FragmentDemo from './Fragments/FragmentDemo';
// import Table from './Fragments/Table';
// import RegCompo from './PureComponents/RegCompo';
// import PureCompo from './PureComponents/PureCompo';
// import ParentCompo from './PureComponents/ParentCompo';
 import RefsDemo from './Refs/RefsDemo';
// import ComponentC from './ContextApi/ComponentC';
// import { UserContext } from './ContextApi/UserContext';

class App extends Component {
  render() {
    return (
	<div className='App'>

		{/* <PropTypesEx num1="10" num2="21"/> */}
		{/* <PropTypeEx1 /> */}
		{/* <UserContext.Provider  value="Cognizant">
			<ComponentC/>
		</UserContext.Provider> */}
		<RefsDemo></RefsDemo>
		{/* <ParentCompo/> */}
	{/* <FragmentDemo></FragmentDemo> */}
	{/* <Table></Table> */}

	{/* <ClickCounter1></ClickCounter1>
	<HoverCounter1></HoverCounter1> */}

	{/* <ClickCounter></ClickCounter>
	<HoverCounter></HoverCounter> */}
	
	</div>
	);
  }
}

export default App
