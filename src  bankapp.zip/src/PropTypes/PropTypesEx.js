import React from 'react'
import PropTypes from 'prop-types'


export const PropTypesEx = (props) => {
  return (
    <p>The sum of {props.num1} and  {props.num2}  
      is  {parseInt(props.num1) + parseInt(props.num2)}</p>
  )
}
PropTypesEx.propTypes = {
    num1: PropTypes.number,
    num2: PropTypes.number
 }
