import React from 'react'
import PropTypes from 'prop-types'  
export const PropTypeEx1 = (props) => {
  return (
    <React.Fragment>
    <div align="center">  
              <h1>ReactJS Props validation</h1>  
              <table border="2">  
                  <tr>  
                      <th>Type</th>  
                      <th>Value</th>  
                      <th>Valid</th>  
                  </tr>  
                <tr>  
                      <td>Array</td>  
                      <td>{props.propArray}</td>  
                      <td>{props.propArray ? "true" : "False"}</td>  
                  </tr>  
                  <tr>  
                      <td>Boolean</td>  
                      <td>{props.propBool ? "true" : "False"}</td>  
                      <td>{props.propBool ? "true" : "False"}</td>  
                  </tr>  
                  <tr>  
                      <td>Function</td>  
                      <td>{props.propFunc(5)}</td>  
                      <td>{props.propFunc(5) ? "true" : "False"}</td>  
                  </tr>  
                  <tr>  
                      <td>String</td>  
                      <td>{props.propString}</td>  
                      <td>{props.propString ? "true" : "False"}</td>  
                  </tr>  
                  <tr>  
                      <td>Number</td>  
                      <td>{props.propNumber}</td>  
                      <td>{props.propNumber ? "true" : "False"}</td>  
                  </tr>  
             </table>  
        </div>  
        </React.Fragment>
  )
}
PropTypeEx1.defaultProps = {  
    propArray: [13,22,53,14,95],  
    propBool: true,  
    propFunc: function(x){return x+5},  
    propNumber: undefined,  
    propString: "welcome",  
}  
PropTypeEx1.propTypes = {  
    propArray: PropTypes.array.isRequired,  
    propBool: PropTypes.bool.isRequired,  
    propFunc: PropTypes.func,  
    propNumber: PropTypes.number,  
    propString: PropTypes.string,   
}  
