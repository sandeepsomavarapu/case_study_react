import React, { Component } from 'react'
import { UserContext } from './UserContext'
class ComponentF extends Component {
  render() {
    return (
      <UserContext.Consumer>
        {
          username=>{
            return <h1>Its time for {username}</h1>
          }
        }

      </UserContext.Consumer>
    )
  }
}

export default ComponentF