import React from 'react'

export default function Columns() {
  return (
    // </React.Fragment>
    <React.Fragment>
        <td>Name</td>
        <td>CTS</td>
    </React.Fragment>
  )
}
