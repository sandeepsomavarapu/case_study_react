import React from 'react'

function FragmentDemo() {
  return (
    <React.Fragment>
    <h1>FragmentDemo</h1>
    <p>This is FragmentDemo Example</p>
    {/* </React.Fragment> */}
    </React.Fragment>
  )
}

export default FragmentDemo