import React, { PureComponent } from 'react'

export class CompoDemo extends PureComponent {
  render() {
    return (
      <div>CompoDemo</div>
    )
  }
}

export default CompoDemo